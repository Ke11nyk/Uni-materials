# Super-Mario-Bros
Remake of the original Super Mario Bros game.

Here are the videos explaining how I did it:

Part 1: https://youtu.be/7D4uoSoQsjw

Part 2: https://youtu.be/6SnGgsgV_GY

## To run the game:
1. Clone the repo
1. Change your working directory to the `Source` by `cd Super-Mario-Bros/Source`
1. Compile with g++ by `g++ *.cpp -std=c++17 -lsfml-graphics -lsfml-window -lsfml-system -o mario`
1. Run the executable.
